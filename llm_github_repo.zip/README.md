# Batch LLM API Processor

A Python script that reads prompts from a plain text file, queries an LLM API using the OpenAI-compatible standard (supports Grok via xAI, Gemma via Groq/OpenRouter, and OpenAI), and writes structured outputs to a JSON file.

## Requirements

- Python 3.7+
- `openai` Python package

## Installation

1. Clone this repository or download the files.
2. Install the required dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Configuration

Set your API key as an environment variable:

```bash
# For Grok (xAI)
export LLM_API_KEY="your_api_key_here"
```

*Note: You can easily configure the script to use different providers by modifying `API_BASE_URL` and `MODEL_NAME` inside `batch_llm_processor.py`.*

## Usage

1. Add your prompts to `prompts.txt` (one prompt per line).
2. Run the script:
   ```bash
   python batch_llm_processor.py
   ```
3. The responses, along with token usage and timestamps, will be saved in `llm_responses.json`.
